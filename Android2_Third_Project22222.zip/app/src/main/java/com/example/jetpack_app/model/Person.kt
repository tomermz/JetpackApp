package com.example.jetpack_app.model

data class Person(
    val id: Int,
    val firstName: String,
    val lastName: String,
    val age: Int
)
